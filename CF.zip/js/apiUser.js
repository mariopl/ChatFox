/*
var user = require ('./db.js');

exports.getAll = function(aCb) {
  db.users.find({}, {}, function(error, ) {
    if (error) {
      aCb(error);
      return;
    }
    aCb(null, users);
  });
};
*/